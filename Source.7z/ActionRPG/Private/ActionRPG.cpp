// Copyright Epic Games, Inc. All Rights Reserved.

#include "ActionRPG.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, ActionRPG, "ActionRPG" );

/** Logging definitions */
DEFINE_LOG_CATEGORY(LogActionRPG);